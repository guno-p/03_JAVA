package ch06.sec08.exam04;

public class Calculator {
    double areaRectangle(int x) {
        return (double) x * (double) x;
    }
    double areaRectangle(int x, int y) {
        return (double) x * (double) y;
    }
}
