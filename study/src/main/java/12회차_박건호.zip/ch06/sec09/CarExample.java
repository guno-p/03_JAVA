package ch06.sec09;

public class CarExample {
    public static void main(String[] args) {
        Car car = new Car("현대자동차");
        car.setSpeed(100);
        car.run();
    }
}
